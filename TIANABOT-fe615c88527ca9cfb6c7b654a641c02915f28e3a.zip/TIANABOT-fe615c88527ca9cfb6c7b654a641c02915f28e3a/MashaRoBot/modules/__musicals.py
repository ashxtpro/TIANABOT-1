__mod_name__ = "MUSIC"

__help__ = """
 ❍ /audio <song name>*:* Uploads the Audio in it's best quality available
 💡Ex: `/song Faded Alan Walker`
 ❍ /saavn <song name>*:* Download song from saavn.
"""
