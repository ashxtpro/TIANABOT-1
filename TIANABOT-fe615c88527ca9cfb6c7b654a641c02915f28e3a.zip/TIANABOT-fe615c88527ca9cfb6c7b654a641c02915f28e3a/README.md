THIS BOT WAS TRANSFER TO NEW REPO:- https://github.com/teamofdevil-x/tianabot
